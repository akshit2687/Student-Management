# STUDENT-INFORMATION-SYSTEM
Student Information Systems are the primary systems for operating colleges.

<p align="center"> 
  <img src="https://1.bp.blogspot.com/-5prwk9w3XJI/WA0OO04387I/AAAAAAAAI9E/2C7Hvqy5mjoBJSc2A7juq0zeL1wM7b_xQCLcB/s1600/Student_Information_System_By_RaxTon_Production.png"/>
</p>

#Included below Modules in Student Information System
-Admin<br>
-Attendance<br>
-Contact<br>
-Course<br>
-Database Connectivity<br>
-Dashboard<br>
-Exam<br>
-Find Record<br>
-Lecture<br>
-Result<br>
-Search Record<br>
-Student<br>
-Subject<br>
