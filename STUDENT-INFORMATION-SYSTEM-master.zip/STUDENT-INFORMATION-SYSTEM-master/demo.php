<?php 

/**
 * @System     HP-pc Rax
 * @author     Rakshit shah <Rakshitshah1994@gmail.com>
 * @copyright  2015-2017 |Rakshit shah
 * @license    http://rakshit.in/license/license.php |  PHP License 3.0
 * @version    1.1
 * @since      File available since Release 1.0.0
 */


session_start();

include("header.php"); 
include("conection.php");
include("modal.php");
?>
<section id="page">
<header id="pageheader" class="normalheader">
<h2 class="sitedescription">
Course Details.  </h2>
</header>

<section id="contents">

<article class="post">
  <header class="postheader">
  <h2>Course Details</h2>
  </header>
  <section class="entry">
  <font color="#330000">
   
   <!-- put code here ---- -->
  </section>
</article>


</section>

<?php 
include("adminmenu.php");
include("footer.php"); 

?>