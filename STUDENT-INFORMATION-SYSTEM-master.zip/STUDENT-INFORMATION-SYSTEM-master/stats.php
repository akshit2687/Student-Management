
<?php 
$filename= url("../index.php");
array stat ( string $filename )
 ?>