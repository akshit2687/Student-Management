<footer id="pagefooter">
<div id="f-content">
<img src="images/bamboo.png" width="96" height="125" alt="bamboo" id="footerimg">
<div id="credits">
<p class="sitecredit"> &copy;2015 @ All Rights Reserved | Rakshit shah</p>
<p class="designcredit">Collage Management System</p>

<!-- /**
 * @System     HP-pc Rax
 * @author     Rakshit shah <Rakshitshah1994@gmail.com>
 * @copyright  2015-2017 |Rakshit shah
 * @license    http://rakshit.in/license/license.php |  PHP License 3.0
 * @version    1.1
 * @since      File available since Release 1.0.0
 */
 -->
</div>
</div>

</footer>

</body>
</html>
